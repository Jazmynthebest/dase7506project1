import torch
from torch.nn import functional as F
from student_v2 import GPT as BaseGPT


class GPT(BaseGPT):
    def forward_features(self, ids):
        x = self.dropout(self.token(ids) + self.pos(torch.arange(ids.shape[1], device=ids.device)))
        for block in self.blocks:
            x = block(x)
        return self.norm(x)

    def continuous_cache(self, ids, hidden, theta, targets=None):
        batch, length = ids.shape
        if length == 1:
            shape = (batch, length) if targets is not None else (batch, length, self.config['vocab'])
            return torch.zeros(shape, device=ids.device)
        features = F.normalize(hidden.float(), dim=-1)
        scores = torch.bmm(features, features[:, :-1].transpose(1, 2)) * theta
        mask = torch.ones(length, length - 1, device=ids.device).tril(-1).bool()
        weights = scores.masked_fill(~mask, -1e9).softmax(-1) * mask
        if targets is not None:
            return (weights * (ids[:, None, 1:] == targets.unsqueeze(-1))).sum(-1)
        probs = torch.zeros(batch, length, self.config['vocab'], device=ids.device)
        probs.scatter_add_(-1, ids[:, None, 1:].expand(-1, length, -1), weights)
        return probs

    def cache_bundle(self, ids, targets=None):
        batch, length = ids.shape
        same = ids.unsqueeze(-1) == ids.unsqueeze(-2)
        match = same
        causal = torch.ones(length, length, device=ids.device).tril(-1)
        weights = match.float() * causal
        groups = weights.any(-1).long()
        for power in range(1, 4):
            match = same & F.pad(match[:, :-1, :-1], (1, 0, 1, 0))
            current = match.float() * causal
            groups = torch.where(current.any(-1), power + 1, groups)
            weights.add_(current, alpha=4 ** power)
        weights = weights[:, :, :-1]
        weights = weights / weights.sum(-1).clamp_min(1).unsqueeze(-1)
        if targets is None:
            probs = torch.zeros(batch, length, self.config['vocab'], device=ids.device)
            probs.scatter_add_(-1, ids[:, None, 1:].expand(-1, length, -1), weights)
        else:
            probs = (weights * (ids[:, None, 1:] == targets.unsqueeze(-1))).sum(-1)
        return probs, groups

    def base_probabilities(self, ids, logits):
        neural = F.log_softmax(logits.float() / self.temperature, -1)
        statistical = self.memory(ids, self.memory_order)
        if 'memory_weights' in self.config:
            limits = self.config.get('memory_boundaries', [.1, .3, .6])
            boundaries = torch.tensor(limits, device=ids.device)
            groups = torch.bucketize(statistical.amax(-1).contiguous(), boundaries)
            if self.config.get('memory_group_agreement', False):
                groups = groups + (len(limits) + 1) * (statistical.argmax(-1) == neural.argmax(-1)).long()
            weight = torch.tensor(self.config['memory_weights'], device=ids.device)[groups].unsqueeze(-1)
        else:
            weight = self.memory_weight
        mixed = neural.exp() * (1 - weight) + statistical * weight
        local, groups = self.cache_bundle(ids)
        gate_values = self.config.get('cache_weights', [0., .2, .2, .2, .2])
        gate = torch.tensor(gate_values, device=ids.device)[groups].unsqueeze(-1)
        mixed.mul_(1 - gate).add_(local * gate)
        return mixed

    def predict_log_probs(self, ids):
        hidden = self.forward_features(ids)
        mixed = self.base_probabilities(ids, self.head(hidden) * self.logit_scale)
        weight = self.config.get('continuous_weight', 0.)
        if weight or 'continuous_weights' in self.config:
            local = self.continuous_cache(ids, hidden, self.config['continuous_theta'])
            if 'continuous_weights' in self.config:
                boundaries = torch.tensor([.1, .3, .6], device=ids.device)
                groups = torch.bucketize(mixed.amax(-1).contiguous(), boundaries)
                weight = torch.tensor(self.config['continuous_weights'], device=ids.device)[groups]
            gate = ((torch.arange(ids.shape[1], device=ids.device) > 0) * weight)
            if gate.ndim == 1:
                gate = gate.unsqueeze(0)
            mixed = mixed * (1 - gate.unsqueeze(-1)) + local * gate.unsqueeze(-1)
        return mixed.clamp_min_(1e-30).log_()


def build_model(config):
    return GPT(config)
