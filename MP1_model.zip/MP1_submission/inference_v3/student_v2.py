import math
import torch
from torch import nn
from torch.nn import functional as F


class Block(nn.Module):
    def __init__(self, width, heads, dropout):
        super().__init__()
        self.heads = heads
        self.norm1 = nn.LayerNorm(width)
        self.norm2 = nn.LayerNorm(width)
        self.qkv = nn.Linear(width, 3 * width)
        self.proj = nn.Linear(width, width)
        self.mlp = nn.Sequential(nn.Linear(width, 4 * width), nn.GELU(), nn.Linear(4 * width, width))
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        batch, length, width = x.shape
        q, k, v = self.qkv(self.norm1(x)).view(batch, length, 3, self.heads, width // self.heads).permute(2, 0, 3, 1, 4)
        attended = F.scaled_dot_product_attention(q, k, v, is_causal=True)
        x = x + self.dropout(self.proj(attended.transpose(1, 2).reshape(batch, length, width)))
        return x + self.dropout(self.mlp(self.norm2(x)))


class CompactMemory(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.vocab = config['vocab']
        self.sizes = config.get('memory_shapes', [])
        self.base = config.get('memory_hash_base', 2048)
        self.register_buffer('unigram', torch.full((self.vocab,), 1 / self.vocab))
        for order, (contexts, entries) in enumerate(self.sizes, 2):
            self.register_buffer(f'keys_{order}', torch.zeros(contexts, dtype=torch.int64))
            self.register_buffer(f'offsets_{order}', torch.zeros(contexts + 1, dtype=torch.int32))
            self.register_buffer(f'ids_{order}', torch.zeros(entries, dtype=torch.int16))
            self.register_buffer(f'probs_{order}', torch.zeros(entries))
            self.register_buffer(f'mass_{order}', torch.zeros(contexts))

    def forward(self, ids, max_order=None, targets=None):
        batch, length = ids.shape
        size = batch * length
        if targets is None:
            probs = self.unigram.expand(size, -1).clone()
        else:
            probs = self.unigram[targets.reshape(-1).clamp_min(0)].clone()
        keys = ids.contiguous()
        positions = torch.arange(length, device=ids.device)
        for order, (contexts, entries) in enumerate(self.sizes, 2):
            if max_order is not None and order > max_order:
                break
            if contexts:
                table = getattr(self, f'keys_{order}')
                index = torch.searchsorted(table, keys.contiguous()).clamp_max(contexts - 1)
                valid = ((table[index] == keys) & (positions >= order - 2)).reshape(-1)
                index = index.reshape(-1)
                offsets = getattr(self, f'offsets_{order}')
                starts = offsets[index].long()
                counts = (offsets[index + 1].long() - starts) * valid
                rows = torch.repeat_interleave(torch.arange(size, device=ids.device), counts)
                ends = counts.cumsum(0)
                locations = torch.arange(len(rows), device=ids.device) + torch.repeat_interleave(starts - (ends - counts), counts)
                mass = getattr(self, f'mass_{order}')[index] * valid
                values = getattr(self, f'probs_{order}')[locations]
                successor = getattr(self, f'ids_{order}')[locations].long()
                if targets is None:
                    probs.mul_((1 - mass).unsqueeze(-1))
                    probs.reshape(-1).index_add_(0, rows * self.vocab + successor, values)
                else:
                    probs.mul_(1 - mass)
                    match = successor == targets.reshape(-1)[rows]
                    probs.index_add_(0, rows[match], values[match])
            keys = F.pad(keys[:, :-1], (1, 0)) * self.base + ids
        return probs.reshape(batch, length, -1) if targets is None else probs.reshape(batch, length)


class GPT(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.config = dict(config)
        self.context = config['context']
        width = config['width']
        self.token = nn.Embedding(config['vocab'], width)
        self.pos = nn.Embedding(self.context, width)
        self.dropout = nn.Dropout(config.get('dropout', .1))
        self.blocks = nn.ModuleList([Block(width, config['heads'], config.get('dropout', .1)) for _ in range(config['depth'])])
        self.norm = nn.LayerNorm(width)
        self.head = nn.Linear(width, config['vocab'], bias=False)
        self.apply(self.initialize)
        self.head.weight = self.token.weight
        self.memory = CompactMemory(config)
        self.temperature = config.get('temperature', 1.)
        self.memory_weight = config.get('memory_weight', 0.)
        self.memory_order = config.get('memory_order', len(self.memory.sizes) + 1)
        self.logit_scale = config.get('logit_scale', 1.)
        self.cache_weight = config.get('cache_weight', 0.)

    def cache(self, ids, targets=None):
        batch, length = ids.shape
        same = ids.unsqueeze(-1) == ids.unsqueeze(-2)
        match = same
        causal = torch.ones(length, length, device=ids.device).tril(-1)
        weights = match.float() * causal
        for power in range(1, self.config.get('cache_order', 4)):
            match = same & F.pad(match[:, :-1, :-1], (1, 0, 1, 0))
            current = match.float() * causal
            if self.config.get('cache_mode', 'weighted') == 'longest':
                weights = torch.where(current.any(-1, keepdim=True), current, weights)
            else:
                weights.add_(current, alpha=4 ** power)
        weights = weights[:, :, :-1]
        total = weights.sum(-1)
        weights = weights / total.clamp_min(1).unsqueeze(-1)
        if targets is not None:
            probs = (weights * (ids[:, None, 1:] == targets.unsqueeze(-1))).sum(-1)
        else:
            probs = torch.zeros(batch, length, self.config['vocab'], device=ids.device)
            probs.scatter_add_(-1, ids[:, None, 1:].expand(-1, length, -1), weights)
        return probs, total > 0

    @staticmethod
    def initialize(module):
        if isinstance(module, (nn.Linear, nn.Embedding)):
            nn.init.normal_(module.weight, std=.02)
            if getattr(module, 'bias', None) is not None:
                nn.init.zeros_(module.bias)

    def forward(self, ids):
        x = self.dropout(self.token(ids) + self.pos(torch.arange(ids.shape[1], device=ids.device)))
        for block in self.blocks:
            x = block(x)
        return self.head(self.norm(x)) * self.logit_scale

    def predict_log_probs(self, ids):
        neural = F.log_softmax(self(ids).float() / self.temperature, dim=-1)
        if not self.memory_weight and not self.cache_weight:
            return neural
        mixed = neural.exp().mul_(1 - self.memory_weight)
        if self.memory_weight:
            mixed.add_(self.memory(ids, self.memory_order), alpha=self.memory_weight)
        if self.cache_weight:
            local, active = self.cache(ids)
            gate = (active * self.cache_weight).unsqueeze(-1)
            mixed.mul_(1 - gate).add_(local * gate)
        return mixed.clamp_min_(1e-30).log_()


def build_model(config):
    return GPT(config)
