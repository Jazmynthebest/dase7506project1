# Final submission

- Full-test BPB: **1.6017257331409482** (display: 1.60173).
- Code and report archive: MP1_code.zip.
- Matching model archive: MP1_model.zip.
- Checkpoint SHA256: f7f1d53281695afb86b0a590036b1cd1679b5a5cf1bc559206d28d33d1dfa54f.
- Author: Huang Leyi. Student ID: 3036708725.
- Report: report/MP1_Report.pdf, six pages.

Publish the source at an immutable commit or release and make the matching inference archive downloadable. The course form requires your student ID, score, immutable code link and checkpoint link. Complete the generated GitHub issue using the same account as any earlier score submission. The stated final deadline is 30 September 2026, end of day UTC+8; the initial score deadline was before 29 September.

These local files have not been uploaded or submitted. Use only this final archive pair for the accepted model.
