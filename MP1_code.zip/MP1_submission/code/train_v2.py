import argparse
import json
import math
import time
from pathlib import Path
import torch
from torch.nn import functional as F
from common import PROTOCOL, load_data, make_model, setup, sha
from evaluate import score


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--run-dir', type=Path, required=True)
    parser.add_argument('--steps', type=int, default=1600)
    parser.add_argument('--learning-rate', type=float, default=.0005)
    parser.add_argument('--seed', type=int, default=41)
    parser.add_argument('--eval-every', type=int, default=200)
    parser.add_argument('--patience', type=int, default=4)
    parser.add_argument('--resume', action='store_true')
    parser.add_argument('--keep-snapshots', action='store_true')
    args = parser.parse_args()
    if not args.resume and args.run_dir.exists() and any(args.run_dir.iterdir()):
        raise ValueError('Use a new output directory')
    args.run_dir.mkdir(parents=True, exist_ok=True)
    device, _ = setup('cpu', 'fp32', 4)
    torch.manual_seed(args.seed)
    source_checkpoint = torch.load(args.checkpoint, map_location='cpu', weights_only=True)
    checkpoint = source_checkpoint
    previous = None
    if args.resume:
        previous = json.loads((args.run_dir / 'metrics.json').read_text())
        resumed = torch.load(args.run_dir / 'resume.pt', map_location='cpu', weights_only=True)
        checkpoint = resumed['checkpoint']
    model, _ = make_model(checkpoint['implementation'], checkpoint['config'], device)
    model.load_state_dict(checkpoint['model'])
    model.train()
    data = load_data()
    tokens = data['train'][0]
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=.1)
    rng = torch.Generator().manual_seed(args.seed)
    source_sha = sha(args.checkpoint)
    parent_tokens = source_checkpoint['train_tokens']
    if args.resume:
        assert previous['source_sha256'] == source_sha
        assert previous['scheduled_steps'] == args.steps
        optimizer.load_state_dict(resumed['optimizer'])
        rng.set_state(resumed['generator'])
        torch.set_rng_state(resumed['torch_rng'])
        history = previous['validation_history']
        best = previous['best_validation_bpb']
        best_step = previous['best_step']
        stale = sum(row['step'] > best_step for row in history)
        first_step = previous['completed_steps'] + 1
        started = time.perf_counter() - previous['seconds']
    else:
        initial = score(model, *data['validation'], device, 'fp32')
        best = initial['bpb']
        initial.pop('window_nll_nats')
        best_step, stale = 0, 0
        torch.save(checkpoint, args.run_dir / 'checkpoint.pt')
        history = [{'step': 0, **initial}]
        first_step = 1
        started = time.perf_counter()
    for step in range(first_step, args.steps + 1):
        batch_start = torch.randint(len(tokens) - 257, (32,), generator=rng)
        batch = tokens[batch_start[:, None] + torch.arange(257)]
        lr = args.learning_rate * min(1., step / 100) * (.15 + .85 * .5 * (1 + math.cos(math.pi * (step - 1) / args.steps)))
        for group in optimizer.param_groups:
            group['lr'] = lr
        optimizer.zero_grad(set_to_none=True)
        loss = F.cross_entropy(model(batch[:, :-1]).flatten(0, 1), batch[:, 1:].flatten())
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.)
        optimizer.step()
        if step % 25 == 0:
            row = dict(step=step, loss=loss.item(), lr=lr, seconds=time.perf_counter() - started)
            print(json.dumps(row), flush=True)
            with (args.run_dir / 'progress.jsonl').open('a') as stream:
                stream.write(json.dumps(row) + '\n')
        if step % args.eval_every == 0 or step == args.steps:
            measured = score(model, *data['validation'], device, 'fp32')
            measured.pop('window_nll_nats')
            history.append(dict(step=step, **measured))
            snapshot = dict(protocol=PROTOCOL, implementation=checkpoint['implementation'], config=checkpoint['config'],
                            model=model.state_dict(), seed=args.seed,
                            train_tokens=parent_tokens + step * 8192,
                            ancestry_sha256=source_sha, parent_train_tokens=parent_tokens)
            if args.keep_snapshots:
                torch.save(snapshot, args.run_dir / f'step_{step}.pt')
            if measured['bpb'] < best:
                best, best_step, stale = measured['bpb'], step, 0
                torch.save(snapshot, args.run_dir / 'checkpoint.pt')
            else:
                stale += 1
            torch.save(dict(checkpoint=snapshot, optimizer=optimizer.state_dict(), generator=rng.get_state(),
                            torch_rng=torch.get_rng_state()), args.run_dir / 'resume.pt')
            result = dict(source_checkpoint=str(args.checkpoint), source_sha256=source_sha,
                          config=checkpoint['config'], parent_train_tokens=parent_tokens, seed=args.seed,
                          completed_steps=step, scheduled_steps=args.steps, best_step=best_step,
                          best_validation_bpb=best, processed_training_targets=parent_tokens + step * 8192,
                          learning_rate=args.learning_rate, optimizer_restart=True,
                          seconds=time.perf_counter() - started, validation_history=history)
            (args.run_dir / 'metrics.json').write_text(json.dumps(result, indent=2) + '\n')
            print(json.dumps({'validation': measured['bpb'], 'best': best, 'step': step}), flush=True)
            if stale >= args.patience:
                break


if __name__ == '__main__':
    main()
