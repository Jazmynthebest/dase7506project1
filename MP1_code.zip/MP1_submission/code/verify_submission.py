import argparse
import json
from pathlib import Path
import torch
from common import ROOT, make_model, sha


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--output', type=Path, default=ROOT / 'evidence/checkpoint_contract.json')
    args = parser.parse_args()
    torch.set_num_threads(4)
    manifest = json.loads((ROOT / 'PACKAGE_MANIFEST.json').read_text())
    fixed = ['common.py', 'evaluate.py', 'model.py', 'configs/baseline.json',
             'data/manifest.json', 'data/tokenizer.json', 'data/wikitext_train.txt',
             'data/wikitext_validation.txt', 'data/wikitext_test.txt']
    checks = {name: sha(ROOT / name) == manifest[f'code/{name}'] for name in fixed}
    if not all(checks.values()):
        raise ValueError(checks)
    checkpoint = torch.load(args.checkpoint, weights_only=True)
    model, _ = make_model(checkpoint['implementation'], checkpoint['config'], 'cpu')
    model.load_state_dict(checkpoint['model'])
    model.eval()
    torch.manual_seed(71)
    ids = torch.randint(0, 2048, (2, 256))
    ids[:, :8] = torch.tensor([11, 51, 81, 27, 41, 11, 51, 81])
    changed = ids.clone()
    changed[:, 117:] = (changed[:, 117:] + 113) % 2048
    with torch.no_grad():
        first = model.predict_log_probs(ids)
        second = model.predict_log_probs(changed)
        alone = model.predict_log_probs(ids[:1])
        repeated = model.predict_log_probs(ids)
        short = model.predict_log_probs(ids[:, :1])
    torch.testing.assert_close(first[:, :117], second[:, :117], atol=1e-6, rtol=1e-6)
    torch.testing.assert_close(first[:1], alone, atol=1e-5, rtol=1e-5)
    torch.testing.assert_close(first, repeated, atol=1e-6, rtol=1e-6)
    torch.testing.assert_close(first[:, :1], short, atol=1e-5, rtol=1e-5)
    assert torch.isfinite(first).all()
    assert first.logsumexp(-1).abs().max() < 1e-6
    result = {'checkpoint_sha256': sha(args.checkpoint), 'fixed_file_checks': checks,
              'causality': True, 'example_independence': True, 'window_reset': True,
              'one_token_prefix': True, 'finite': True,
              'max_log_normalization_error': first.logsumexp(-1).abs().max().item()}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
