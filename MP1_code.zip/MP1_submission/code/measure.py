import argparse
import json
import statistics
import subprocess
import sys
import time
from pathlib import Path
import psutil


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', required=True, type=Path)
    parser.add_argument('--output-dir', required=True, type=Path)
    parser.add_argument('--split', choices=['validation', 'test'], default='test')
    parser.add_argument('--repeats', type=int, default=3)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    for repeat in range(args.repeats):
        output = args.output_dir / f'{args.split}_{repeat + 1}.json'
        command = [sys.executable, 'evaluate.py', '--checkpoint', str(args.checkpoint),
                   '--device', 'cpu', '--precision', 'fp32', '--threads', '4',
                   '--split', args.split, '--output', str(output)]
        start = time.perf_counter()
        with output.with_suffix('.log').open('w') as stream:
            process = subprocess.Popen(command, stdout=stream, stderr=subprocess.STDOUT)
            observed = psutil.Process(process.pid)
            peak = 0
            while process.poll() is None:
                try:
                    family = [observed] + observed.children(recursive=True)
                    resident = 0
                    for member in family:
                        info = member.memory_info()
                        resident += max(info.rss, getattr(info, 'peak_wset', info.rss))
                    peak = max(peak, resident)
                except psutil.NoSuchProcess:
                    pass
                time.sleep(.05)
        if process.returncode:
            raise RuntimeError(output.with_suffix('.log').read_text())
        result = json.loads(output.read_text())
        row = {'repeat': repeat + 1, 'bpb': result['bpb'], 'scoring_seconds': result['seconds'],
               'process_seconds': time.perf_counter() - start, 'peak_resident_bytes': peak}
        rows.append(row)
        print(json.dumps(row), flush=True)
    summary = {'checkpoint': str(args.checkpoint), 'split': args.split, 'threads': 4,
               'precision': 'fp32', 'median_scoring_seconds': statistics.median(x['scoring_seconds'] for x in rows),
               'peak_resident_bytes': max(x['peak_resident_bytes'] for x in rows),
               'checkpoint_bytes': args.checkpoint.stat().st_size, 'runs': rows}
    (args.output_dir / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
