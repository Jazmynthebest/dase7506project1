import argparse
from pathlib import Path
import torch
from common import sha


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoints', type=Path, nargs='+', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    items = [torch.load(path, weights_only=True) for path in args.checkpoints]
    reference = items[-1]
    assert all(item['config'] == reference['config'] for item in items)
    assert all(item['implementation'] == reference['implementation'] for item in items)
    state = {}
    for key, value in reference['model'].items():
        if value.is_floating_point():
            state[key] = torch.stack([item['model'][key] for item in items]).mean(0)
        else:
            assert all(torch.equal(item['model'][key], value) for item in items)
            state[key] = value.clone()
    result = dict(reference, model=state, train_tokens=max(item['train_tokens'] for item in items),
                  averaging_sources=[dict(path=str(path), sha256=sha(path)) for path in args.checkpoints],
                  averaging_rule='equal weights from one training trajectory')
    args.output.parent.mkdir(parents=True, exist_ok=True)
    torch.save(result, args.output)
    print(args.output)


if __name__ == '__main__':
    main()
