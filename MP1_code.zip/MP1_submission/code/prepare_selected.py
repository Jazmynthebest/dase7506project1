import argparse
from pathlib import Path
import torch
from common import sha


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    item = torch.load(args.checkpoint, map_location='cpu', weights_only=True)
    item['config']['dropout'] = 0.0
    item['selected_from_sha256'] = sha(args.checkpoint)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    torch.save(item, args.output)


if __name__ == '__main__':
    main()
