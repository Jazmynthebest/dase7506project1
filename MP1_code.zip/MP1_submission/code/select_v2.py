import argparse
import itertools
import json
import math
import time
from pathlib import Path
import numpy as np
import torch
from common import PROTOCOL, load_data, setup, sha, windows
from student_v2 import build_model


@torch.no_grad()
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--memory', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--temperatures', type=float, nargs='+', default=[.9, .95, 1., 1.05, 1.1])
    parser.add_argument('--weights', type=float, nargs='+', default=[0., .1, .2, .3, .4, .5, .6, .7, .8])
    parser.add_argument('--cache-weights', type=float, nargs='+', default=[0., .05, .1, .15, .2])
    parser.add_argument('--orders', type=int, nargs='+')
    parser.add_argument('--cache-mode', choices=['weighted', 'longest'], default='weighted')
    parser.add_argument('--cache-order', type=int, default=4)
    args = parser.parse_args()
    setup('cpu', 'fp32', 4)
    started = time.perf_counter()
    checkpoint = torch.load(args.checkpoint, weights_only=True)
    memory = torch.load(args.memory, weights_only=True)
    config = dict(checkpoint['config'], **memory['config'])
    config.update(cache_mode=args.cache_mode, cache_order=args.cache_order)
    model = build_model(config).eval()
    state = {k: v for k, v in checkpoint['model'].items() if not k.startswith('memory.')}
    state.update({f'memory.{k}': v for k, v in memory['state'].items()})
    model.load_state_dict(state)
    tokens, byte_count = load_data()['validation']
    temperatures = args.temperatures
    orders = args.orders or list(range(3, len(model.memory.sizes) + 2))
    weights = args.weights
    cache_weights = args.cache_weights
    grid = list(itertools.product(temperatures, orders, weights, cache_weights))
    nll = np.zeros(len(grid), dtype=np.float64)
    memory_nll = {order: 0. for order in orders}
    for batch_index, (x, y) in enumerate(windows(tokens, batch_size=16)):
        valid = y != -100
        target = y.clamp_min(0).unsqueeze(-1)
        logits = model(x).float()
        neural = {temp: (logits / temp).log_softmax(-1).gather(-1, target).squeeze(-1)[valid].exp().double() for temp in temperatures}
        local, active = model.cache(x, y)
        local, active = local[valid].double(), active[valid].double()
        statistical = {order: model.memory(x, order, targets=y)[valid].double() for order in orders}
        for order in orders:
            memory_nll[order] -= statistical[order].clamp_min(1e-30).log().sum().item()
        for index, (temp, order, weight, cache_weight) in enumerate(grid):
            mixed = neural[temp] * (1 - weight) + statistical[order] * weight
            gate = active * cache_weight
            mixed = mixed * (1 - gate) + local * gate
            nll[index] -= mixed.clamp_min(1e-30).log().sum().item()
        if (batch_index + 1) % 20 == 0:
            print(json.dumps({'validation_batches': batch_index + 1}), flush=True)
    results = [dict(temperature=t, memory_order=o, memory_weight=w, cache_weight=c,
                    bpb=float(loss / math.log(2) / byte_count)) for (t, o, w, c), loss in zip(grid, nll)]
    results.sort(key=lambda x: x['bpb'])
    best = results[0]
    config.update({k: v for k, v in best.items() if k != 'bpb'})
    bundle = dict(protocol=PROTOCOL, implementation='student_v2', config=config, model=model.state_dict(),
                  seed=checkpoint['seed'], train_tokens=checkpoint['train_tokens'],
                  ancestry_sha256=sha(args.checkpoint), memory_sha256=sha(args.memory),
                  memory_fit_tokens=memory['metadata']['training_tokens'], selection_split='validation')
    args.output_dir.mkdir(parents=True, exist_ok=True)
    torch.save(bundle, args.output_dir / 'checkpoint.pt')
    summary = dict(best=best, source_checkpoint=str(args.checkpoint), source_sha256=sha(args.checkpoint),
                   memory_file=str(args.memory), neural_training_targets=checkpoint['train_tokens'],
                   memory_fit_tokens=memory['metadata']['training_tokens'], seconds=time.perf_counter() - started,
                   standalone_memory={str(o): v / math.log(2) / byte_count for o, v in memory_nll.items()}, results=results)
    (args.output_dir / 'selection.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps({k: v for k, v in summary.items() if k != 'results'}, indent=2))


if __name__ == '__main__':
    main()
