import json
import time
from pathlib import Path
import torch
from torch.nn import functional as F
from student_v2 import build_model


torch.set_num_threads(4)
torch.manual_seed(17)
results = []
for width, depth in [(128, 4), (192, 4), (192, 6), (256, 4)]:
    config = dict(vocab=2048, context=256, width=width, depth=depth, heads=4, dropout=.1)
    model = build_model(config)
    optimizer = torch.optim.AdamW(model.parameters(), lr=.001)
    x = torch.randint(0, 2048, (32, 257))
    times = []
    for step in range(5):
        started = time.perf_counter()
        optimizer.zero_grad(set_to_none=True)
        loss = F.cross_entropy(model(x[:, :-1]).flatten(0, 1), x[:, 1:].flatten())
        loss.backward()
        optimizer.step()
        if step:
            times.append(time.perf_counter() - started)
    model.eval()
    with torch.no_grad():
        started = time.perf_counter()
        for _ in range(5):
            model.predict_log_probs(x[:, :-1])
        evaluation_seconds = (time.perf_counter() - started) / 5
    row = dict(config=config, parameters=sum(p.numel() for p in model.parameters()),
               train_step_seconds=sum(times) / len(times), evaluation_batch_seconds=evaluation_seconds)
    results.append(row)
    print(json.dumps(row), flush=True)
    del model, optimizer
Path('evidence/v2').mkdir(parents=True, exist_ok=True)
Path('evidence/v2/architecture_benchmark.json').write_text(json.dumps(results, indent=2) + '\n')
