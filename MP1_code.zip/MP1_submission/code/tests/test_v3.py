import unittest
import torch
from student_v3 import build_model


class V3Tests(unittest.TestCase):
    def setUp(self):
        torch.set_num_threads(2)
        torch.manual_seed(83)
        self.model = build_model(dict(vocab=2048, width=32, heads=4, depth=2,
                                      context=256, dropout=.1,
                                      memory_weights=[.2] * 8,
                                      memory_group_agreement=True,
                                      cache_weights=[0., .1, .3, .4, .5],
                                      continuous_theta=10.,
                                      continuous_weights=[.1, .05, .025, 0.])).eval()
        self.ids = torch.tensor([[3, 7, 3, 8, 3, 7, 3], [7, 3, 7, 8, 3, 7, 3]])
        self.targets = torch.tensor([[7, 3, 8, 3, 7, 3, 7], [3, 7, 8, 3, 7, 3, 8]])

    def test_selection_paths_match_full_distributions(self):
        with torch.no_grad():
            hidden = self.model.forward_features(self.ids)
            dense = self.model.continuous_cache(self.ids, hidden, 10.)
            direct = self.model.continuous_cache(self.ids, hidden, 10., self.targets)
            torch.testing.assert_close(direct, dense.gather(-1, self.targets.unsqueeze(-1)).squeeze(-1))
            dense, groups = self.model.cache_bundle(self.ids)
            direct, other_groups = self.model.cache_bundle(self.ids, self.targets)
            torch.testing.assert_close(direct, dense.gather(-1, self.targets.unsqueeze(-1)).squeeze(-1))
            torch.testing.assert_close(groups, other_groups)

    def test_continuous_cache_only_uses_observed_successors(self):
        hidden = torch.ones(1, 5, 32)
        ids = self.ids[:1, :5]
        probs = self.model.continuous_cache(ids, hidden, 10.)
        torch.testing.assert_close(probs.sum(-1), torch.tensor([[0., 1., 1., 1., 1.]]))
        self.assertEqual(probs[0, 1, 7].item(), 1.)
        self.assertEqual(probs[0, 1, 8].item(), 0.)
        self.assertAlmostEqual(probs[0, 4, 3].item(), .5)
        self.assertAlmostEqual(probs[0, 4, 7].item(), .25)
        self.assertAlmostEqual(probs[0, 4, 8].item(), .25)

    def test_full_predictor_is_causal_and_resets(self):
        changed = self.ids.clone()
        changed[:, 4:] = 111
        with torch.no_grad():
            first = self.model.predict_log_probs(self.ids)
            future = self.model.predict_log_probs(changed)
            repeated = self.model.predict_log_probs(self.ids)
            alone = self.model.predict_log_probs(self.ids[:1])
            prefix = self.model.predict_log_probs(self.ids[:, :1])
        torch.testing.assert_close(first[:, :4], future[:, :4], atol=1e-6, rtol=1e-6)
        torch.testing.assert_close(first, repeated)
        torch.testing.assert_close(first[:1], alone, atol=1e-5, rtol=1e-5)
        torch.testing.assert_close(first[:, :1], prefix, atol=1e-5, rtol=1e-5)
        torch.testing.assert_close(first.logsumexp(-1), torch.zeros(2, 7), atol=1e-6, rtol=1e-6)

    def test_finer_confidence_groups_use_matching_agreement_weight(self):
        self.model.config.update(memory_boundaries=[.02, .05, .1, .2, .35, .5, .7],
                                 memory_weights=[.1] * 15 + [.75], continuous_weights=[0.] * 4)
        with torch.no_grad():
            self.model.token.weight.zero_()
            self.model.memory.unigram.fill_(.2 / 2047)
            self.model.memory.unigram[0] = .8
            probs = self.model.predict_log_probs(torch.tensor([[1, 2, 3, 4]])).exp()
        torch.testing.assert_close(probs.sum(-1), torch.ones(1, 4))
        torch.testing.assert_close(probs[0, :, 0], torch.full((4,), .75 * .8 + .25 / 2048))


if __name__ == '__main__':
    unittest.main()
