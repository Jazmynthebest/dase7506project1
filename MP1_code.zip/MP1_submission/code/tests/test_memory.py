import unittest
import torch
from student import NGramMemory, build_model


class MemoryTests(unittest.TestCase):
    def setUp(self):
        torch.set_num_threads(2)
        self.config = dict(vocab=2048, width=32, heads=4, depth=2, context=256,
                           memory_sizes=[2, 1], memory_topk=2, memory_weight=.4)
        self.model = build_model(self.config).eval()
        memory = self.model.memory
        memory.keys_2.copy_(torch.tensor([3, 7]))
        memory.ids_2.copy_(torch.tensor([[7, 8], [3, 9]]))
        memory.probs_2.copy_(torch.tensor([[.4, .2], [.3, .2]]))
        memory.keys_3.copy_(torch.tensor([3 * 2048 + 7]))
        memory.ids_3.copy_(torch.tensor([[11, 12]]))
        memory.probs_3.copy_(torch.tensor([[.5, .1]]))

    def test_exact_backoff(self):
        probs = self.model.memory(torch.tensor([[3, 7]]))
        self.assertAlmostEqual(probs[0, 0, 7].item(), .4 + .4 / 2048, places=6)
        self.assertAlmostEqual(probs[0, 1, 11].item(), .5 + .4 * .5 / 2048, places=6)
        torch.testing.assert_close(probs.sum(-1), torch.ones(1, 2))

    def test_active_memory_is_causal_and_resets(self):
        x = torch.tensor([[3, 7, 11, 3, 7], [7, 3, 7, 3, 7]])
        changed = x.clone()
        changed[:, 3:] = 19
        with torch.no_grad():
            before = self.model.predict_log_probs(x)
            after = self.model.predict_log_probs(changed)
            alone = self.model.predict_log_probs(x[:1])
            repeated = self.model.predict_log_probs(x)
        torch.testing.assert_close(before[:, :3], after[:, :3], atol=1e-6, rtol=1e-6)
        torch.testing.assert_close(before[:1], alone, atol=1e-5, rtol=1e-5)
        torch.testing.assert_close(before, repeated)
        torch.testing.assert_close(before.logsumexp(-1), torch.zeros(2, 5), atol=1e-6, rtol=1e-6)

    def test_start_of_window_does_not_invent_prefix(self):
        memory = NGramMemory(dict(vocab=2048, memory_topk=1, memory_sizes=[0, 1]))
        memory.keys_3.fill_(7)
        memory.ids_3.fill_(11)
        memory.probs_3.fill_(.9)
        probs = memory(torch.tensor([[7]]))
        torch.testing.assert_close(probs[0, 0], memory.unigram)


if __name__ == '__main__':
    unittest.main()
