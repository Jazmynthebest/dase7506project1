import unittest
import torch
from student_v2 import build_model


class V2Tests(unittest.TestCase):
    def setUp(self):
        torch.set_num_threads(2)
        torch.manual_seed(17)
        self.model = build_model(dict(vocab=2048, width=32, heads=4, depth=2, context=256,
                                      memory_shapes=[[2, 4], [1, 2]], memory_weight=.4,
                                      cache_weight=.15, dropout=.1)).eval()
        memory = self.model.memory
        memory.keys_2.copy_(torch.tensor([3, 7]))
        memory.offsets_2.copy_(torch.tensor([0, 2, 4]))
        memory.ids_2.copy_(torch.tensor([7, 8, 3, 9]))
        memory.probs_2.copy_(torch.tensor([.4, .2, .3, .2]))
        memory.mass_2.copy_(torch.tensor([.6, .5]))
        memory.keys_3.copy_(torch.tensor([3 * 2048 + 7]))
        memory.offsets_3.copy_(torch.tensor([0, 2]))
        memory.ids_3.copy_(torch.tensor([11, 12]))
        memory.probs_3.copy_(torch.tensor([.5, .1]))
        memory.mass_3.copy_(torch.tensor([.6]))

    def test_target_path_matches_distribution(self):
        x = torch.tensor([[3, 7, 3, 7, 11], [7, 3, 7, 8, 3]])
        y = torch.tensor([[7, 11, 9, 7, 3], [3, 11, 8, 7, 3]])
        full = self.model.memory(x)
        direct = self.model.memory(x, targets=y)
        torch.testing.assert_close(direct, full.gather(-1, y.unsqueeze(-1)).squeeze(-1))
        torch.testing.assert_close(full.sum(-1), torch.ones(2, 5))

    def test_cache_uses_observed_successors(self):
        cache, active = self.model.cache(torch.tensor([[3, 7, 3, 8, 3]]))
        self.assertFalse(active[0, 0])
        self.assertAlmostEqual(cache[0, 2, 7].item(), 1.)
        self.assertAlmostEqual(cache[0, 4, 7].item(), .5)
        self.assertAlmostEqual(cache[0, 4, 8].item(), .5)

    def test_full_predictor_contract(self):
        x = torch.tensor([[3, 7, 3, 7, 11, 3, 7], [7, 3, 7, 8, 3, 7, 3]])
        changed = x.clone()
        changed[:, 4:] = 111
        with torch.no_grad():
            before = self.model.predict_log_probs(x)
            after = self.model.predict_log_probs(changed)
            alone = self.model.predict_log_probs(x[:1])
            repeated = self.model.predict_log_probs(x)
            short = self.model.predict_log_probs(x[:, :1])
        torch.testing.assert_close(before[:, :4], after[:, :4], atol=1e-6, rtol=1e-6)
        torch.testing.assert_close(before[:1], alone, atol=1e-5, rtol=1e-5)
        torch.testing.assert_close(before, repeated)
        torch.testing.assert_close(before[:, :1], short, atol=1e-5, rtol=1e-5)
        torch.testing.assert_close(before.logsumexp(-1), torch.zeros(2, 7), atol=1e-6, rtol=1e-6)


if __name__ == '__main__':
    unittest.main()
