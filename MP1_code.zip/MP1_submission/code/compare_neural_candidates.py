import argparse
import json
from pathlib import Path
import torch
from common import load_data, setup, sha
from evaluate import score
from student_v3 import build_model


@torch.no_grad()
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoints', type=Path, nargs='+', required=True)
    parser.add_argument('--hybrid', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    device, _ = setup('cpu', 'fp32', 4)
    hybrid = torch.load(args.hybrid, weights_only=True)
    memory = {key: value for key, value in hybrid['model'].items() if key.startswith('memory.')}
    data = load_data()['validation']
    rows = []
    for path in args.checkpoints:
        neural = torch.load(path, weights_only=True)
        config = dict(hybrid['config'], **neural['config'])
        config['logit_scale'] = neural['config'].get('logit_scale', 1.)
        model = build_model(config).eval()
        state = {key: value for key, value in neural['model'].items() if not key.startswith('memory.')}
        model.load_state_dict(dict(state, **memory))
        result = score(model, *data, device, 'fp32', batch_size=8)
        result.pop('window_nll_nats')
        rows.append(dict(checkpoint=str(path), checkpoint_sha256=sha(path),
                         neural_training_targets=neural['train_tokens'], **result))
        output = dict(split='validation', batch_size=8,
                      calibration_checkpoint=str(args.hybrid),
                      calibration_sha256=sha(args.hybrid),
                      calibration_fixed=True, results=rows)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(output, indent=2) + '\n')
        print(json.dumps(rows[-1]), flush=True)
        del model, neural, state


if __name__ == '__main__':
    main()
