import torch
from torch import nn
from torch.nn import functional as F
from model import GPT


class NGramMemory(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.vocab = config['vocab']
        self.topk = config.get('memory_topk', 12)
        self.sizes = config.get('memory_sizes', [])
        self.register_buffer('unigram', torch.full((self.vocab,), 1 / self.vocab))
        for order, size in enumerate(self.sizes, 2):
            self.register_buffer(f'keys_{order}', torch.zeros(size, dtype=torch.int64))
            self.register_buffer(f'ids_{order}', torch.zeros(size, self.topk, dtype=torch.int16))
            self.register_buffer(f'probs_{order}', torch.zeros(size, self.topk))

    def forward(self, ids, max_order=None):
        batch, length = ids.shape
        probs = self.unigram.expand(batch, length, -1).clone()
        keys = ids
        positions = torch.arange(length, device=ids.device)
        for order, size in enumerate(self.sizes, 2):
            if max_order is not None and order > max_order:
                break
            if size:
                table = getattr(self, f'keys_{order}')
                index = torch.searchsorted(table, keys).clamp_max(size - 1)
                valid = (table[index] == keys) & (positions >= order - 2)
                mass = getattr(self, f'probs_{order}')[index] * valid.unsqueeze(-1)
                probs.mul_(1 - mass.sum(-1, keepdim=True))
                probs.scatter_add_(-1, getattr(self, f'ids_{order}')[index].long(), mass)
            keys = F.pad(keys[:, :-1], (1, 0)) * self.vocab + ids
        return probs


class StudentGPT(GPT):
    def __init__(self, config):
        super().__init__(config)
        self.memory = NGramMemory(config)
        self.memory_weight = config.get('memory_weight', 0.)
        self.temperature = config.get('temperature', 1.)
        self.memory_order = config.get('memory_order', len(self.memory.sizes) + 1)

    def predict_log_probs(self, ids):
        neural = F.log_softmax(self(ids).float() / self.temperature, dim=-1)
        if self.memory_weight == 0:
            return neural
        mixed = neural.exp().mul_(1 - self.memory_weight)
        mixed.add_(self.memory(ids, self.memory_order), alpha=self.memory_weight)
        return mixed.clamp_min_(1e-30).log_()


def build_model(config):
    return StudentGPT(config)
