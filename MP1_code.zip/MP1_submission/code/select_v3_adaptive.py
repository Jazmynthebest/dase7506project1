import argparse
import json
import math
import time
from pathlib import Path
import numpy as np
import torch
from common import PROTOCOL, load_data, setup, sha, windows
from student_v3 import build_model


@torch.no_grad()
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--memory', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--agreement-groups', action='store_true')
    parser.add_argument('--temperatures', type=float, nargs='+', default=[.85, .9, .95, 1., 1.05])
    parser.add_argument('--memory-order', type=int, default=5)
    parser.add_argument('--memory-boundaries', type=float, nargs='+', default=[.1, .3, .6])
    args = parser.parse_args()
    setup('cpu', 'fp32', 4)
    started = time.perf_counter()
    checkpoint = torch.load(args.checkpoint, weights_only=True)
    memory = torch.load(args.memory, weights_only=True)
    config = dict(checkpoint['config'], **memory['config'], memory_order=args.memory_order)
    config['dropout'] = checkpoint['config'].get('dropout', 0.)
    config['memory_group_agreement'] = args.agreement_groups
    config['memory_boundaries'] = args.memory_boundaries
    bins = len(args.memory_boundaries) + 1
    group_total = bins * (2 if args.agreement_groups else 1)
    model = build_model(config).eval()
    state = {k: v for k, v in checkpoint['model'].items() if not k.startswith('memory.')}
    state.update({f'memory.{k}': v for k, v in memory['state'].items()})
    model.load_state_dict(state)
    tokens, byte_count = load_data()['validation']
    temps = args.temperatures
    collected = {key: [] for key in ['stat', 'cache', 'mg', 'cg'] + temps}
    boundaries = torch.tensor(args.memory_boundaries)
    for batch_index, (x, y) in enumerate(windows(tokens, batch_size=8)):
        valid = y != -100
        target = y.clamp_min(0).unsqueeze(-1)
        logits = model(x).float()
        for temp in temps:
            values = (logits / temp).log_softmax(-1).gather(-1, target).squeeze(-1)[valid].exp()
            collected[temp].append(values.numpy())
        statistical = model.memory(x, args.memory_order)
        groups = torch.bucketize(statistical.amax(-1).contiguous(), boundaries)
        if args.agreement_groups:
            groups = groups + bins * (statistical.argmax(-1) == logits.argmax(-1)).long()
        collected['mg'].append(groups[valid].numpy())
        collected['stat'].append(statistical.gather(-1, target).squeeze(-1)[valid].numpy())
        local, groups = model.cache_bundle(x, y)
        collected['cache'].append(local[valid].numpy())
        collected['cg'].append(groups[valid].numpy())
        if (batch_index + 1) % 40 == 0:
            print(json.dumps({'validation_batches': batch_index + 1}), flush=True)
    values = {key: np.concatenate(rows) for key, rows in collected.items()}
    stat, cache, mg, cg = (values[key] for key in ('stat', 'cache', 'mg', 'cg'))
    grid = np.arange(.0, 1.001, .05)
    results = []
    for temp in temps:
        neural = values[temp].astype(np.float64)
        memory_weights = np.full(group_total, .6)
        cache_weights = np.array([0., .1, .35, .4, .45])
        for iteration in range(5):
            for group in range(group_total):
                mask = mg == group
                gates = cache_weights[cg[mask]]
                losses = [-np.log(np.maximum((neural[mask] * (1-w) + stat[mask] * w) * (1-gates)
                                            + cache[mask] * gates, 1e-30)).sum() for w in grid]
                memory_weights[group] = grid[int(np.argmin(losses))]
            mixed = neural * (1 - memory_weights[mg]) + stat * memory_weights[mg]
            for group in range(1, 5):
                mask = cg == group
                losses = [-np.log(np.maximum(mixed[mask] * (1-w) + cache[mask] * w, 1e-30)).sum() for w in grid]
                cache_weights[group] = grid[int(np.argmin(losses))]
        final = mixed * (1 - cache_weights[cg]) + cache * cache_weights[cg]
        results.append(dict(temperature=temp, memory_weights=memory_weights.tolist(),
                            cache_weights=cache_weights.tolist(),
                            bpb=float(-np.log(np.maximum(final, 1e-30)).sum() / math.log(2) / byte_count)))
    results.sort(key=lambda row: row['bpb'])
    best = results[0]
    config.update({key: value for key, value in best.items() if key != 'bpb'})
    config['memory_weight'] = .6
    bundle = dict(protocol=PROTOCOL, implementation='student_v3', config=config, model=model.state_dict(),
                  seed=checkpoint['seed'], train_tokens=checkpoint['train_tokens'],
                  ancestry_sha256=sha(args.checkpoint), memory_sha256=sha(args.memory),
                  memory_fit_tokens=memory['metadata']['training_tokens'], selection_split='validation')
    args.output_dir.mkdir(parents=True, exist_ok=True)
    torch.save(bundle, args.output_dir / 'checkpoint.pt')
    summary = dict(best=best, source_checkpoint=str(args.checkpoint), source_sha256=sha(args.checkpoint),
                   memory_file=str(args.memory), seconds=time.perf_counter() - started,
                   memory_group_counts=np.bincount(mg, minlength=group_total).tolist(),
                   cache_group_counts=np.bincount(cg, minlength=5).tolist(), results=results,
                   iterations=5, gate_grid=grid.tolist(), memory_group_boundaries=args.memory_boundaries)
    (args.output_dir / 'selection.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps({key: value for key, value in summary.items() if key != 'results'}, indent=2))


if __name__ == '__main__':
    main()
