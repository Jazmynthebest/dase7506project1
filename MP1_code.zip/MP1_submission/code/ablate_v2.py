import argparse
import json
from pathlib import Path
import torch
from common import load_data, setup, sha
from evaluate import score
from student_v2 import build_model


@torch.no_grad()
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    device, _ = setup('cpu', 'fp32', 4)
    checkpoint = torch.load(args.checkpoint, weights_only=True)
    model = build_model(checkpoint['config'])
    model.load_state_dict(checkpoint['model'])
    data = load_data()['validation']
    rows = []
    original = (model.memory_weight, model.cache_weight, model.temperature)
    variants = [('Final predictor', original),
                ('Without window cache', (original[0], 0., original[2])),
                ('Without static memory', (0., original[1], original[2])),
                ('Neural component only', (0., 0., original[2])),
                ('Without temperature scaling', (original[0], original[1], 1.))]
    for name, values in variants:
        model.memory_weight, model.cache_weight, model.temperature = values
        result = score(model, *data, device, 'fp32')
        result.pop('window_nll_nats')
        rows.append(dict(name=name, **result))
        print(json.dumps(rows[-1]), flush=True)
    baseline = torch.load('runs/baseline/checkpoint.pt', weights_only=True)
    config = dict(checkpoint['config'])
    config.update(baseline['config'])
    config['logit_scale'] = 1.
    early = build_model(config)
    state = {k: v for k, v in checkpoint['model'].items() if k.startswith('memory.')}
    state.update(baseline['model'])
    early.load_state_dict(state)
    result = score(early, *data, device, 'fp32')
    result.pop('window_nll_nats')
    early_result = dict(name='Early hybrid with final settings', neural_targets=baseline['train_tokens'],
                        memory_targets=checkpoint['memory_fit_tokens'] - 1, **result)
    print(json.dumps(early_result), flush=True)
    output = dict(checkpoint_sha256=sha(args.checkpoint), split='validation',
                  same_weights=rows, matched_exposure_hybrid=early_result,
                  early_hybrid_settings_selected_with_later_neural_weights=True)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2) + '\n')


if __name__ == '__main__':
    main()
