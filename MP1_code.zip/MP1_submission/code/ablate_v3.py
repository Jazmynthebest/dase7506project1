import argparse
import json
from pathlib import Path
import torch
from common import load_data, setup, sha
from evaluate import score
from student_v3 import build_model


@torch.no_grad()
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    device, _ = setup('cpu', 'fp32', 4)
    checkpoint = torch.load(args.checkpoint, weights_only=True)
    original = checkpoint['config']
    model = build_model(original).eval()
    model.load_state_dict(checkpoint['model'])
    data = load_data()['validation']
    zero_continuous = dict(continuous_weight=0., continuous_weights=[0.] * 4)
    groups = len(original.get('memory_weights', [.6] * 8))
    variants = [
        ('Full predictor', {}),
        ('Without continuous cache', zero_continuous),
        ('Fixed statistical mixture', dict(memory_weights=[.6] * groups)),
        ('Fixed exact-cache mixture', dict(cache_weights=[0., .2, .2, .2, .2])),
        ('Earlier fixed mixture with identical weights',
         dict(memory_weights=[.6] * groups, cache_weights=[0., .2, .2, .2, .2],
              temperature=.95, **zero_continuous)),
        ('Without statistical branch', dict(memory_weights=[0.] * groups)),
        ('Neural component only', dict(memory_weights=[0.] * groups, cache_weights=[0.] * 5,
                                       temperature=1., **zero_continuous)),
    ]
    rows = []
    for name, changes in variants:
        model.config = dict(original, **changes)
        model.temperature = model.config.get('temperature', 1.)
        result = score(model, *data, device, 'fp32')
        result.pop('window_nll_nats')
        rows.append(dict(name=name, configuration_changes=changes, **result))
        output = dict(checkpoint_sha256=sha(args.checkpoint), split='validation',
                      neural_training_targets=checkpoint['train_tokens'],
                      memory_training_targets=checkpoint['memory_fit_tokens'] - 1,
                      parameters_fixed=True, ablations_recalibrated=False, results=rows)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(output, indent=2) + '\n')
        print(json.dumps(rows[-1]), flush=True)


if __name__ == '__main__':
    main()
