import argparse
import json
import time
from pathlib import Path
import numpy as np
import torch
from tokenizers import Tokenizer
from common import ROOT, sha


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--output', type=Path, default=ROOT / 'runs/memory.pt')
    p.add_argument('--topk', type=int, default=12)
    p.add_argument('--max-order', type=int, default=5)
    p.add_argument('--min-count', type=int, default=2)
    p.add_argument('--discount', type=float, default=.75)
    args = p.parse_args()
    started = time.perf_counter()
    manifest = json.loads((ROOT / 'data/manifest.json').read_text())
    source = ROOT / 'data/wikitext_train.txt'
    if sha(source) != manifest['sha256'][source.name]:
        raise ValueError('Training data checksum mismatch')
    tokenizer = Tokenizer.from_file(str(ROOT / 'data/tokenizer.json'))
    tokens = np.asarray(tokenizer.encode(source.read_bytes().decode('utf-8')).ids, dtype=np.int64)
    vocab = 2048
    unigram = np.bincount(tokens, minlength=vocab).astype(np.float64) + .1
    state = {'unigram': torch.from_numpy((unigram / unigram.sum()).astype(np.float32))}
    sizes, details = [], []
    for order in range(2, args.max_order + 1):
        contexts = np.zeros(len(tokens) - order + 1, dtype=np.int64)
        for position in range(order - 1):
            contexts = contexts * vocab + tokens[position:position + len(contexts)]
        context_keys, context_counts = np.unique(contexts, return_counts=True)
        sequences, counts = np.unique(contexts * vocab + tokens[order - 1:], return_counts=True)
        keep = counts >= (1 if order == 2 else args.min_count)
        sequences, counts = sequences[keep], counts[keep]
        prefix = sequences // vocab
        ranking = np.lexsort((-counts, prefix))
        prefix, sequences, counts = prefix[ranking], sequences[ranking], counts[ranking]
        keys, first = np.unique(prefix, return_index=True)
        groups = np.searchsorted(keys, prefix)
        rank = np.arange(len(prefix)) - first[groups]
        keep = rank < args.topk
        ids = np.zeros((len(keys), args.topk), dtype=np.int16)
        probs = np.zeros((len(keys), args.topk), dtype=np.float32)
        totals = context_counts[np.searchsorted(context_keys, keys)]
        ids[groups[keep], rank[keep]] = sequences[keep] % vocab
        probs[groups[keep], rank[keep]] = (counts[keep] - args.discount) / totals[groups[keep]]
        state[f'keys_{order}'] = torch.from_numpy(keys.copy())
        state[f'ids_{order}'] = torch.from_numpy(ids)
        state[f'probs_{order}'] = torch.from_numpy(probs)
        sizes.append(len(keys))
        details.append({'order': order, 'contexts': len(keys), 'retained_ngrams': int(keep.sum())})
        print(json.dumps(details[-1]), flush=True)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    config = {'memory_sizes': sizes, 'memory_topk': args.topk}
    metadata = {'seconds': time.perf_counter() - started, 'training_tokens': len(tokens),
                'training_sha256': sha(source), 'topk': args.topk, 'min_count': args.min_count,
                'discount': args.discount, 'orders': details}
    torch.save({'config': config, 'state': state, 'metadata': metadata}, args.output)
    metadata['bytes'] = args.output.stat().st_size
    args.output.with_suffix('.json').write_text(json.dumps(metadata, indent=2) + '\n')
    print(json.dumps(metadata, indent=2))


if __name__ == '__main__':
    main()
