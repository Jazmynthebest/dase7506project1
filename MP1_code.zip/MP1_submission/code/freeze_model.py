import json
import shutil
from datetime import datetime, timezone
from pathlib import Path
import torch
from common import ROOT, sha


def main():
    source = ROOT / 'runs/hybrid_extended/checkpoint.pt'
    destination = ROOT.parent / 'inference'
    if (destination / 'FREEZE.json').exists():
        raise RuntimeError('A frozen bundle already exists')
    destination.mkdir(exist_ok=True)
    checkpoint = torch.load(source, weights_only=True)
    checkpoint['memory_fit_targets'] = checkpoint['memory_fit_tokens'] - 1
    torch.save(checkpoint, destination / 'checkpoint.pt')
    for name in ('student.py', 'model.py'):
        shutil.copy2(ROOT / name, destination / name)
    shutil.copy2(ROOT / 'data/tokenizer.json', destination / 'tokenizer.json')
    files = {path.name: {'sha256': sha(path), 'bytes': path.stat().st_size}
             for path in sorted(destination.iterdir()) if path.is_file()}
    frozen = {'frozen_at_utc': datetime.now(timezone.utc).isoformat(),
              'protocol': checkpoint['protocol'], 'selection_split': 'validation',
              'config': checkpoint['config'], 'neural_training_targets': checkpoint['train_tokens'],
              'memory_training_targets': checkpoint['memory_fit_targets'],
              'inference_assets_bytes': sum(row['bytes'] for row in files.values()), 'files': files,
              'baseline_checkpoint_sha256': sha(ROOT / 'runs/baseline/checkpoint.pt'),
              'evaluator_sha256': sha(ROOT / 'evaluate.py'),
              'fixed_data_manifest_sha256': sha(ROOT / 'data/manifest.json')}
    (destination / 'FREEZE.json').write_text(json.dumps(frozen, indent=2) + '\n')
    print(json.dumps(frozen, indent=2))


if __name__ == '__main__':
    main()
