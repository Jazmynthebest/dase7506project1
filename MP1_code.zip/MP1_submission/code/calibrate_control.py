import argparse
import json
import math
import time
from pathlib import Path
import torch
from common import load_data, make_model, setup, windows


@torch.no_grad()
def main():
    p = argparse.ArgumentParser()
    p.add_argument('--checkpoint', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    setup('cpu', 'fp32', 4)
    started = time.perf_counter()
    checkpoint = torch.load(args.checkpoint, weights_only=True)
    model, _ = make_model(checkpoint['implementation'], checkpoint['config'], 'cpu')
    model.load_state_dict(checkpoint['model'])
    model.eval()
    tokens, byte_count = load_data()['validation']
    temperatures = [.9, .95, 1., 1.05, 1.1]
    totals = dict.fromkeys(temperatures, 0.)
    for x, y in windows(tokens):
        logits = model(x)
        for temperature in temperatures:
            logp = (logits / temperature).log_softmax(-1)
            losses = -logp.gather(-1, y.clamp_min(0).unsqueeze(-1)).squeeze(-1)
            totals[temperature] += losses[y != -100].double().sum().item()
    rows = [{'temperature': t, 'bpb': v / math.log(2) / byte_count} for t, v in totals.items()]
    result = {'best': min(rows, key=lambda x: x['bpb']), 'results': rows,
              'seconds': time.perf_counter() - started, 'split': 'validation'}
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
