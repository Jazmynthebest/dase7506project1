import argparse
import json
import math
import time
from pathlib import Path
import numpy as np
import torch
from common import load_data, setup, sha, windows
from student_v3 import build_model


@torch.no_grad()
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--adaptive', action='store_true')
    args = parser.parse_args()
    setup('cpu', 'fp32', 4)
    started = time.perf_counter()
    checkpoint = torch.load(args.checkpoint, weights_only=True)
    model = build_model(checkpoint['config']).eval()
    model.load_state_dict(checkpoint['model'])
    tokens, byte_count = load_data()['validation']
    thetas = [5., 10., 20., 40., 80.]
    weights = [0., .025, .05, .1, .15, .2, .3]
    group_total = 4 if args.adaptive else 1
    nll = np.zeros((len(thetas), group_total, len(weights)))
    for batch_index, (x, y) in enumerate(windows(tokens, batch_size=8)):
        hidden = model.forward_features(x)
        probs = model.base_probabilities(x, model.head(hidden) * model.logit_scale)
        valid = y != -100
        base = probs.gather(-1, y.clamp_min(0).unsqueeze(-1)).squeeze(-1)[valid].double()
        groups = (torch.bucketize(probs.amax(-1).contiguous(), torch.tensor([.1, .3, .6]))[valid]
                  if args.adaptive else torch.zeros_like(base, dtype=torch.long))
        active = (torch.arange(x.shape[1]) > 0).expand_as(x)[valid]
        for index, theta in enumerate(thetas):
            local = model.continuous_cache(x, hidden, theta, y)[valid].double()
            for col, weight in enumerate(weights):
                gate = active * weight
                mixed = base * (1 - gate) + local * gate
                losses = -mixed.clamp_min(1e-30).log()
                for group in range(group_total):
                    nll[index, group, col] += losses[groups == group].sum().item()
        if (batch_index + 1) % 40 == 0:
            print(json.dumps({'validation_batches': batch_index + 1}), flush=True)
    if args.adaptive:
        results = []
        for row, theta in enumerate(thetas):
            chosen = nll[row].argmin(-1)
            results.append(dict(continuous_theta=theta, continuous_weights=[weights[i] for i in chosen],
                                bpb=float(nll[row, np.arange(group_total), chosen].sum() / math.log(2) / byte_count)))
    else:
        results = [dict(continuous_theta=theta, continuous_weight=weight,
                        bpb=float(nll[row, 0, col] / math.log(2) / byte_count))
                   for row, theta in enumerate(thetas) for col, weight in enumerate(weights)]
    results.sort(key=lambda row: row['bpb'])
    best = results[0]
    config = dict(checkpoint['config'], **{key: value for key, value in best.items() if key != 'bpb'})
    output = dict(checkpoint, config=config, calibration_parent_sha256=sha(args.checkpoint))
    args.output_dir.mkdir(parents=True, exist_ok=True)
    torch.save(output, args.output_dir / 'checkpoint.pt')
    summary = dict(best=best, source_checkpoint=str(args.checkpoint), source_sha256=sha(args.checkpoint),
                   seconds=time.perf_counter() - started, results=results)
    (args.output_dir / 'selection.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(best))


if __name__ == '__main__':
    main()
