import argparse
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path
import torch
from common import ROOT, sha


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', type=Path, required=True)
    args = parser.parse_args()
    destination = ROOT.parent / 'inference_v2'
    if destination.exists():
        raise RuntimeError('A V2 bundle already exists')
    checkpoint = torch.load(args.checkpoint, weights_only=True)
    assert checkpoint['selection_split'] == 'validation'
    destination.mkdir()
    shutil.copy2(args.checkpoint, destination / 'checkpoint.pt')
    shutil.copy2(ROOT / 'student_v2.py', destination / 'student_v2.py')
    shutil.copy2(ROOT / 'data/tokenizer.json', destination / 'tokenizer.json')
    files = {p.name: dict(sha256=sha(p), bytes=p.stat().st_size) for p in destination.iterdir()}
    result = dict(frozen_at_utc=datetime.now(timezone.utc).isoformat(),
                  protocol=checkpoint['protocol'], selection_split='validation',
                  source_checkpoint=str(args.checkpoint), config=checkpoint['config'],
                  neural_training_targets=checkpoint['train_tokens'],
                  memory_training_targets=checkpoint['memory_fit_tokens'] - 1,
                  inference_assets_bytes=sum(v['bytes'] for v in files.values()), files=files,
                  baseline_checkpoint_sha256=sha(ROOT / 'runs/baseline/checkpoint.pt'),
                  evaluator_sha256=sha(ROOT / 'evaluate.py'),
                  fixed_data_manifest_sha256=sha(ROOT / 'data/manifest.json'))
    assert result['inference_assets_bytes'] < 64 * 1024 ** 2
    (destination / 'FREEZE.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
