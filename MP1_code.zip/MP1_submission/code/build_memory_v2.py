import argparse
import json
import time
from pathlib import Path
import numpy as np
import torch
from tokenizers import Tokenizer
from common import ROOT, sha


def discounts(counts):
    histogram = np.bincount(np.minimum(counts, 5), minlength=6)
    n1, n2, n3, n4 = histogram[1:5].astype(float)
    if min(n1, n2, n3) == 0:
        return np.array([.75, .75, .75])
    y = n1 / (n1 + 2 * n2)
    return np.clip([1 - 2 * y * n2 / n1, 2 - 3 * y * n3 / n2, 3 - 4 * y * n4 / n3], .1, [0.99, 1.99, 2.99])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--smoothing', choices=['absolute', 'kn'], default='kn')
    parser.add_argument('--trigram-min-count', type=int, default=1)
    parser.add_argument('--trigram-cap', type=int, default=64)
    parser.add_argument('--max-order', type=int, choices=[5, 6], default=5)
    parser.add_argument('--prune-by-context', action='store_true')
    parser.add_argument('--convert-v1', type=Path)
    args = parser.parse_args()
    started = time.perf_counter()
    state, shapes, details = {}, [], []
    if args.convert_v1:
        previous = torch.load(args.convert_v1, weights_only=True)
        state['unigram'] = previous['state']['unigram']
        for order, contexts in enumerate(previous['config']['memory_sizes'], 2):
            source = previous['state']
            keep = source[f'probs_{order}'] > 0
            lengths = keep.sum(-1)
            state[f'keys_{order}'] = source[f'keys_{order}']
            state[f'offsets_{order}'] = torch.cat([torch.zeros(1, dtype=torch.int64), lengths.cumsum(0)]).int()
            state[f'ids_{order}'] = source[f'ids_{order}'][keep]
            state[f'probs_{order}'] = source[f'probs_{order}'][keep]
            state[f'mass_{order}'] = source[f'probs_{order}'].sum(-1)
            shapes.append([contexts, int(lengths.sum())])
        metadata = dict(previous['metadata'], converted_from_sha256=sha(args.convert_v1), fit_targets_new=0)
    else:
        source = ROOT / 'data/wikitext_train.txt'
        manifest = json.loads((ROOT / 'data/manifest.json').read_text())
        assert sha(source) == manifest['sha256'][source.name]
        tokenizer = Tokenizer.from_file(str(ROOT / 'data/tokenizer.json'))
        tokens = np.asarray(tokenizer.encode(source.read_bytes().decode('utf-8')).ids, dtype=np.int64)
        sequences = {}
        for order in range(2, 6):
            keys = np.zeros(len(tokens) - order + 1, dtype=np.int64)
            for offset in range(order):
                keys = keys * 2048 + tokens[offset:offset + len(keys)]
            sequences[order] = np.unique(keys, return_counts=True)
        if args.max_order == 6:
            contexts = np.zeros(len(tokens) - 5, dtype=np.int64)
            for offset in range(5):
                contexts = contexts * 2048 + tokens[offset:offset + len(contexts)]
            pairs = np.empty(len(contexts), dtype=[('context', '<i8'), ('next', '<i2')])
            pairs['context'], pairs['next'] = contexts, tokens[5:]
            sequences[6] = np.unique(pairs, return_counts=True)
        if args.smoothing == 'kn':
            unigram = np.bincount(sequences[2][0] % 2048, minlength=2048).astype(float) + .1
        else:
            unigram = np.bincount(tokens, minlength=2048).astype(float) + .1
        state['unigram'] = torch.from_numpy((unigram / unigram.sum()).astype(np.float32))
        for order in range(2, args.max_order + 1):
            if args.smoothing == 'kn' and order < args.max_order:
                longer = sequences[order + 1][0]
                suffix = (longer['context'] % (2048 ** 4)) * 2048 + longer['next'] if order == 5 else longer % (2048 ** order)
                keys, counts = np.unique(suffix, return_counts=True)
            else:
                keys, counts = sequences[order]
            prefix = keys['context'] if order == 6 else keys // 2048
            successors = keys['next'] if order == 6 else keys % 2048
            contexts, first = np.unique(prefix, return_index=True)
            totals = np.add.reduceat(counts, first)
            discount = discounts(counts) if args.smoothing == 'kn' else np.array([.75, .75, .75])
            threshold = 1 if order == 2 else args.trigram_min_count if order == 3 else 2
            keep = counts >= threshold
            if args.prune_by_context and order >= 4:
                keep = totals[np.searchsorted(contexts, prefix)] >= threshold
            successors, counts, prefix = successors[keep], counts[keep], prefix[keep]
            ranked = np.lexsort((-counts, prefix))
            successors, counts, prefix = successors[ranked], counts[ranked], prefix[ranked]
            retained_contexts, first, lengths = np.unique(prefix, return_index=True, return_counts=True)
            group = np.searchsorted(retained_contexts, prefix)
            rank = np.arange(len(prefix)) - first[group]
            cap = {2: 2048, 3: args.trigram_cap, 4: 32, 5: 16, 6: 16}[order]
            keep = rank < cap
            successors, counts, prefix = successors[keep], counts[keep], prefix[keep]
            retained_contexts, first, lengths = np.unique(prefix, return_index=True, return_counts=True)
            denominator = totals[np.searchsorted(contexts, prefix)]
            probs = ((counts - discount[np.minimum(counts, 3) - 1]) / denominator).astype(np.float32)
            offsets = np.concatenate([np.zeros(1, dtype=np.int64), lengths.cumsum()]).astype(np.int32)
            state[f'keys_{order}'] = torch.from_numpy(retained_contexts.copy())
            state[f'offsets_{order}'] = torch.from_numpy(offsets)
            state[f'ids_{order}'] = torch.from_numpy(successors.astype(np.int16))
            state[f'probs_{order}'] = torch.from_numpy(probs.copy())
            state[f'mass_{order}'] = torch.from_numpy(np.add.reduceat(probs, first).astype(np.float32))
            shapes.append([len(retained_contexts), len(successors)])
            details.append(dict(order=order, contexts=len(retained_contexts), entries=len(successors),
                                discount=discount.tolist(), min_count=threshold, cap=cap))
            print(json.dumps(details[-1]), flush=True)
        metadata = dict(smoothing=args.smoothing, orders=details, training_tokens=len(tokens),
                        fit_targets_new=len(tokens) - 1, training_sha256=sha(source),
                        pruning='context_total' if args.prune_by_context else 'successor_count')
    metadata['seconds'] = time.perf_counter() - started
    args.output.parent.mkdir(parents=True, exist_ok=True)
    torch.save(dict(config=dict(memory_shapes=shapes), state=state, metadata=metadata), args.output)
    metadata['bytes'] = args.output.stat().st_size
    args.output.with_suffix('.json').write_text(json.dumps(metadata, indent=2) + '\n')
    print(json.dumps(metadata, indent=2))


if __name__ == '__main__':
    main()
