import json
from pathlib import Path
import torch
from common import make_model, sha
from student_v2 import build_model


torch.set_num_threads(4)
source = Path('runs/extended/checkpoint.pt')
checkpoint = torch.load(source, weights_only=True)
original, _ = make_model(checkpoint['implementation'], checkpoint['config'], 'cpu')
original.load_state_dict(checkpoint['model'])
original.eval()
config = dict(checkpoint['config'], width=256, heads=8, dropout=.1, logit_scale=.5)
model = build_model(config).eval()
state = model.state_dict()
for name, value in checkpoint['model'].items():
    if name.startswith('memory.'):
        continue
    if name in ('token.weight', 'pos.weight', 'head.weight'):
        state[name] = value.repeat(1, 2)
    elif '.qkv.weight' in name:
        state[name] = value.reshape(3, 128, 128).repeat(1, 2, 2).reshape(768, 256) * .5
    elif '.qkv.bias' in name:
        state[name] = value.reshape(3, 128).repeat(1, 2).reshape(-1)
    elif value.ndim == 2:
        state[name] = value.repeat(2, 2) * .5
    else:
        state[name] = value.repeat(2)
model.load_state_dict(state)
torch.manual_seed(123)
x = torch.randint(0, 2048, (2, 256))
with torch.no_grad():
    expected = original(x)
    actual = model(x)
torch.testing.assert_close(expected, actual, atol=2e-5, rtol=2e-5)
output = Path('runs/v2_wide_init')
output.mkdir(parents=True, exist_ok=True)
torch.save(dict(protocol=checkpoint['protocol'], implementation='student_v2', config=config,
                model=model.state_dict(), seed=checkpoint['seed'], train_tokens=checkpoint['train_tokens'],
                ancestry_sha256=sha(source)), output / 'checkpoint.pt')
result = dict(source_sha256=sha(source), max_logit_error=(actual - expected).abs().max().item(),
              parameters=sum(p.numel() for p in model.parameters()), config=config)
(output / 'metrics.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
