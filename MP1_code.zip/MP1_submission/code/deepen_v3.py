import argparse
import json
from pathlib import Path
import torch
from common import make_model, sha
from student_v2 import build_model


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--depth', type=int, default=6)
    args = parser.parse_args()
    torch.set_num_threads(4)
    torch.manual_seed(97)
    checkpoint = torch.load(args.checkpoint, weights_only=True)
    original, _ = make_model(checkpoint['implementation'], checkpoint['config'], 'cpu')
    original.load_state_dict(checkpoint['model'])
    original.eval()
    config = dict(checkpoint['config'], depth=args.depth)
    model = build_model(config).eval()
    state = model.state_dict()
    state.update(checkpoint['model'])
    for index in range(checkpoint['config']['depth'], args.depth):
        for suffix in ('proj.weight', 'proj.bias', 'mlp.2.weight', 'mlp.2.bias'):
            state[f'blocks.{index}.{suffix}'].zero_()
    model.load_state_dict(state)
    inputs = torch.randint(0, config['vocab'], (2, 256))
    with torch.no_grad():
        before, after = original(inputs), model(inputs)
    torch.testing.assert_close(before, after, atol=1e-6, rtol=1e-6)
    result = dict(checkpoint, config=config, model=model.state_dict(), implementation='student_v2',
                  ancestry_sha256=sha(args.checkpoint), added_identity_blocks=args.depth - checkpoint['config']['depth'])
    args.output_dir.mkdir(parents=True, exist_ok=True)
    torch.save(result, args.output_dir / 'checkpoint.pt')
    metadata = dict(config=config, parameters=sum(p.numel() for p in model.parameters()),
                    initial_max_logit_error=(before - after).abs().max().item(),
                    source_sha256=sha(args.checkpoint), neural_targets=checkpoint['train_tokens'])
    (args.output_dir / 'metrics.json').write_text(json.dumps(metadata, indent=2) + '\n')
    print(json.dumps(metadata, indent=2))


if __name__ == '__main__':
    main()
