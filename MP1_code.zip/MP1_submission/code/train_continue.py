import argparse
import json
import math
import time
from pathlib import Path
import torch
from torch.nn import functional as F
from common import PROTOCOL, load_data, make_model, setup, sha
from evaluate import score


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--run-dir', type=Path, required=True)
    parser.add_argument('--steps', type=int, default=1200)
    parser.add_argument('--extra-targets', type=int)
    parser.add_argument('--learning-rate', type=float, default=.0004)
    parser.add_argument('--seed', type=int, default=29)
    parser.add_argument('--eval-every', type=int, default=300)
    parser.add_argument('--save-last', action='store_true')
    args = parser.parse_args()
    if args.extra_targets is not None:
        args.steps = math.ceil(args.extra_targets / (32 * 256))
    target_budget = args.extra_targets or args.steps * 32 * 256
    if args.run_dir.exists() and any(args.run_dir.iterdir()):
        raise ValueError('Use a new output directory')
    args.run_dir.mkdir(parents=True, exist_ok=True)
    device, _ = setup('cpu', 'fp32', 4)
    torch.manual_seed(args.seed)
    checkpoint = torch.load(args.checkpoint, map_location='cpu', weights_only=True)
    model, _ = make_model(checkpoint['implementation'], checkpoint['config'], device)
    model.load_state_dict(checkpoint['model'])
    data = load_data()
    tokens = data['train'][0]
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=.1)
    rng = torch.Generator().manual_seed(args.seed)
    origin_sha = sha(args.checkpoint)
    history = []
    best = float('inf')
    started = time.perf_counter()
    log = args.run_dir / 'progress.jsonl'
    processed = 0
    for step in range(1, args.steps + 1):
        count = min(32 * 256, target_budget - processed)
        starts = torch.randint(len(tokens) - 257, (math.ceil(count / 256),), generator=rng)
        batch = tokens[starts[:, None] + torch.arange(257)]
        lr = args.learning_rate * min(1., step / 50) * (.1 + .9 * .5 * (1 + math.cos(math.pi * (step - 1) / args.steps)))
        for group in optimizer.param_groups:
            group['lr'] = lr
        optimizer.zero_grad(set_to_none=True)
        loss = F.cross_entropy(model(batch[:, :-1]).flatten(0, 1).float()[:count], batch[:, 1:].flatten()[:count])
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.)
        optimizer.step()
        processed += count
        if step % 100 == 0:
            row = {'step': step, 'loss': loss.item(), 'elapsed_seconds': time.perf_counter() - started}
            print(json.dumps(row), flush=True)
            with log.open('a') as stream:
                stream.write(json.dumps(row) + '\n')
        if step % args.eval_every == 0 or step == args.steps:
            validation = score(model, *data['validation'], device, 'fp32')
            validation.pop('window_nll_nats')
            row = {'step': step, 'train_tokens': checkpoint['train_tokens'] + processed,
                   **validation}
            history.append(row)
            if args.save_last:
                torch.save({'protocol': PROTOCOL, 'implementation': checkpoint['implementation'],
                            'config': checkpoint['config'], 'model': model.state_dict(), 'seed': args.seed,
                            'train_tokens': row['train_tokens'], 'ancestry_sha256': origin_sha,
                            'parent_train_tokens': checkpoint['train_tokens'], 'continuation_step': step},
                           args.run_dir / 'last.pt')
            if validation['bpb'] < best:
                best = validation['bpb']
                torch.save({'protocol': PROTOCOL, 'implementation': checkpoint['implementation'],
                            'config': checkpoint['config'], 'model': model.state_dict(), 'seed': args.seed,
                            'train_tokens': row['train_tokens'], 'ancestry_sha256': origin_sha,
                            'parent_train_tokens': checkpoint['train_tokens'], 'continuation_step': step},
                           args.run_dir / 'checkpoint.pt')
            print(json.dumps({'validation': row, 'best_bpb': best}), flush=True)
            result = {'source_checkpoint': str(args.checkpoint), 'source_sha256': origin_sha,
                      'parent_train_tokens': checkpoint['train_tokens'], 'seed': args.seed,
                      'learning_rate': args.learning_rate, 'optimizer_restart': True,
                      'scheduled_steps': args.steps, 'completed_steps': step, 'best_validation_bpb': best,
                      'processed_training_targets': checkpoint['train_tokens'] + processed,
                      'seconds': time.perf_counter() - started, 'validation_history': history}
            (args.run_dir / 'metrics.json').write_text(json.dumps(result, indent=2) + '\n')


if __name__ == '__main__':
    main()
