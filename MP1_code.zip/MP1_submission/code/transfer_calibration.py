import argparse
from pathlib import Path
import torch
from common import sha


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--neural', type=Path, required=True)
    parser.add_argument('--hybrid', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    neural = torch.load(args.neural, weights_only=True)
    hybrid = torch.load(args.hybrid, weights_only=True)
    config = dict(hybrid['config'], **neural['config'])
    config['logit_scale'] = neural['config'].get('logit_scale', 1.)
    state = {key: value for key, value in neural['model'].items() if not key.startswith('memory.')}
    state.update({key: value for key, value in hybrid['model'].items() if key.startswith('memory.')})
    result = dict(hybrid, config=config, model=state, seed=neural['seed'], train_tokens=neural['train_tokens'],
                  ancestry_sha256=sha(args.neural), calibration_parent_sha256=sha(args.hybrid))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    torch.save(result, args.output)
    print(args.output)


if __name__ == '__main__':
    main()
