import argparse
import itertools
import json
import math
import time
from pathlib import Path
import numpy as np
import torch
from common import PROTOCOL, load_data, setup, sha, windows
from student import build_model


def assemble(checkpoint, memory):
    config = dict(checkpoint['config'], **memory['config'])
    model = build_model(config)
    state = dict(checkpoint['model'])
    state.update({f'memory.{key}': value for key, value in memory['state'].items()})
    model.load_state_dict(state)
    return model.eval(), config


@torch.no_grad()
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--memory', type=Path, default=Path('runs/memory.pt'))
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    setup('cpu', 'fp32', 4)
    started = time.perf_counter()
    checkpoint = torch.load(args.checkpoint, map_location='cpu', weights_only=True)
    memory = torch.load(args.memory, map_location='cpu', weights_only=True)
    model, config = assemble(checkpoint, memory)
    tokens, byte_count = load_data()['validation']
    temperatures = [.9, .95, 1., 1.05, 1.1]
    weights = [0., .1, .2, .3, .4, .5, .6, .7, .8]
    orders = list(range(2, len(model.memory.sizes) + 2))
    grid = list(itertools.product(temperatures, orders, weights))
    nll = np.zeros(len(grid), dtype=np.float64)
    standalone_nll = {order: 0. for order in orders}
    for batch_index, (x, y) in enumerate(windows(tokens)):
        valid = y != -100
        target = y.clamp_min(0).unsqueeze(-1)
        logits = model(x).float()
        neural = {temp: (logits / temp).log_softmax(-1).gather(-1, target).squeeze(-1)[valid].exp().double()
                  for temp in temperatures}
        statistical = {}
        for order in orders:
            statistical[order] = model.memory(x, order).gather(-1, target).squeeze(-1)[valid].double()
            standalone_nll[order] -= statistical[order].clamp_min(1e-30).log().sum().item()
        for index, (temp, order, weight) in enumerate(grid):
            mixed = neural[temp] * (1 - weight) + statistical[order] * weight
            nll[index] -= mixed.clamp_min(1e-30).log().sum().item()
        if (batch_index + 1) % 10 == 0:
            print(json.dumps({'validation_batches': batch_index + 1}), flush=True)
    results = [{'temperature': temp, 'memory_order': order, 'memory_weight': weight,
                'bpb': float(value / math.log(2) / byte_count)}
               for (temp, order, weight), value in zip(grid, nll)]
    results.sort(key=lambda row: row['bpb'])
    best = results[0]
    config.update({key: best[key] for key in ('temperature', 'memory_order', 'memory_weight')})
    args.output_dir.mkdir(parents=True, exist_ok=True)
    bundle = {'protocol': PROTOCOL, 'implementation': 'student', 'config': config,
              'model': model.state_dict(), 'seed': checkpoint['seed'],
              'train_tokens': checkpoint['train_tokens'],
              'ancestry_sha256': sha(args.checkpoint), 'memory_sha256': sha(args.memory),
              'memory_fit_tokens': memory['metadata']['training_tokens'],
              'selection_split': 'validation'}
    torch.save(bundle, args.output_dir / 'checkpoint.pt')
    summary = {'best': best, 'seconds': time.perf_counter() - started,
               'source_checkpoint': str(args.checkpoint), 'source_sha256': sha(args.checkpoint),
               'neural_training_targets': checkpoint['train_tokens'],
               'memory_fit_tokens': memory['metadata']['training_tokens'],
               'standalone_memory': {str(order): value / math.log(2) / byte_count
                                     for order, value in standalone_nll.items()},
               'results': results}
    (args.output_dir / 'selection.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps({key: value for key, value in summary.items() if key != 'results'}, indent=2))


if __name__ == '__main__':
    main()
