import argparse
import itertools
import json
import math
import time
from pathlib import Path
import numpy as np
import torch
from common import PROTOCOL, load_data, setup, sha, windows
from student_v3 import build_model


@torch.no_grad()
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--memory', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--temperatures', type=float, nargs='+', default=[.9, .95, 1., 1.05])
    parser.add_argument('--weights', type=float, nargs='+', default=[.4, .5, .6, .7, .8])
    args = parser.parse_args()
    setup('cpu', 'fp32', 4)
    started = time.perf_counter()
    checkpoint = torch.load(args.checkpoint, weights_only=True)
    memory = torch.load(args.memory, weights_only=True)
    config = dict(checkpoint['config'], **memory['config'], memory_order=5)
    model = build_model(config).eval()
    state = {k: v for k, v in checkpoint['model'].items() if not k.startswith('memory.')}
    state.update({f'memory.{k}': v for k, v in memory['state'].items()})
    model.load_state_dict(state)
    tokens, byte_count = load_data()['validation']
    grid = list(itertools.product(args.temperatures, args.weights))
    gates = np.arange(0., .951, .05)
    nll = np.zeros((len(grid), 5, len(gates)), dtype=np.float64)
    group_counts = np.zeros(5, dtype=np.int64)
    for batch_index, (x, y) in enumerate(windows(tokens, batch_size=8)):
        valid = y != -100
        target = y.clamp_min(0).unsqueeze(-1)
        logits = model(x).float()
        neural = {temp: (logits / temp).log_softmax(-1).gather(-1, target).squeeze(-1)[valid].exp().double()
                  for temp in args.temperatures}
        statistical = model.memory(x, 5, targets=y)[valid].double()
        local, groups = model.cache_bundle(x, y)
        local, groups = local[valid].double(), groups[valid]
        for group in range(5):
            mask = groups == group
            group_counts[group] += int(mask.sum())
            cache_prob = local[mask]
            gate_tensor = torch.from_numpy(gates).unsqueeze(0)
            if group == 0:
                gate_tensor = gate_tensor * 0
            for index, (temp, weight) in enumerate(grid):
                base_prob = neural[temp][mask] * (1 - weight) + statistical[mask] * weight
                values = base_prob[:, None] * (1 - gate_tensor) + cache_prob[:, None] * gate_tensor
                nll[index, group] -= values.clamp_min(1e-30).log().sum(0).numpy()
        if (batch_index + 1) % 40 == 0:
            print(json.dumps({'validation_batches': batch_index + 1}), flush=True)
    results = []
    for index, (temp, weight) in enumerate(grid):
        chosen = nll[index].argmin(-1)
        selected_gates = gates[chosen].tolist()
        selected_gates[0] = 0.
        loss = nll[index, np.arange(5), chosen].sum()
        results.append(dict(temperature=temp, memory_weight=weight, cache_weights=selected_gates,
                            bpb=float(loss / math.log(2) / byte_count)))
    results.sort(key=lambda row: row['bpb'])
    best = results[0]
    config.update({key: value for key, value in best.items() if key != 'bpb'})
    bundle = dict(protocol=PROTOCOL, implementation='student_v3', config=config, model=model.state_dict(),
                  seed=checkpoint['seed'], train_tokens=checkpoint['train_tokens'],
                  ancestry_sha256=sha(args.checkpoint), memory_sha256=sha(args.memory),
                  memory_fit_tokens=memory['metadata']['training_tokens'], selection_split='validation')
    args.output_dir.mkdir(parents=True, exist_ok=True)
    torch.save(bundle, args.output_dir / 'checkpoint.pt')
    summary = dict(best=best, source_checkpoint=str(args.checkpoint), source_sha256=sha(args.checkpoint),
                   memory_file=str(args.memory), neural_training_targets=checkpoint['train_tokens'],
                   seconds=time.perf_counter() - started, cache_group_counts=group_counts.tolist(),
                   gate_grid=gates.tolist(), results=results)
    (args.output_dir / 'selection.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps({key: value for key, value in summary.items() if key != 'results'}, indent=2))


if __name__ == '__main__':
    main()
