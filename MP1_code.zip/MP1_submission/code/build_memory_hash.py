import argparse
import json
import time
from pathlib import Path
import numpy as np
import torch
from tokenizers import Tokenizer
from common import ROOT, sha
from build_memory_v2 import discounts


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--max-order', type=int, default=8)
    args = parser.parse_args()
    started = time.perf_counter()
    source = ROOT / 'data/wikitext_train.txt'
    manifest = json.loads((ROOT / 'data/manifest.json').read_text())
    assert sha(source) == manifest['sha256'][source.name]
    tokenizer = Tokenizer.from_file(str(ROOT / 'data/tokenizer.json'))
    tokens = np.asarray(tokenizer.encode(source.read_bytes().decode('utf-8')).ids, dtype=np.int64)
    pairs = np.unique(tokens[:-1] * 2048 + tokens[1:])
    unigram = np.bincount(pairs % 2048, minlength=2048).astype(float) + .1
    state = {'unigram': torch.from_numpy((unigram / unigram.sum()).astype(np.float32))}
    shapes, details = [], []
    base = 1000003
    pair_type = np.dtype([('context', '<i8'), ('next', '<i2')])
    for order in range(2, args.max_order + 1):
        shift = int(order < args.max_order)
        count = len(tokens) - order + 1 - shift
        hashes = np.zeros(count, dtype=np.uint64)
        for offset in range(order - 1):
            hashes = hashes * np.uint64(base) + tokens[shift + offset:shift + offset + count].astype(np.uint64)
        hashes = hashes.view(np.int64)
        _, first, inverse = np.unique(hashes, return_index=True, return_inverse=True)
        collisions = 0
        for offset in range(order - 1):
            piece = tokens[shift + offset:shift + offset + count]
            collisions += int(np.count_nonzero(piece[first[inverse]] != piece))
        if collisions:
            raise ValueError(f'Observed hash collision at order {order}')
        del inverse, first
        if shift:
            triples = np.empty(count, dtype=[('context', '<i8'), ('next', '<i2'), ('previous', '<i2')])
            triples['context'] = hashes
            triples['next'] = tokens[order:]
            triples['previous'] = tokens[:count]
            unique = np.unique(triples)
            pairs = np.empty(len(unique), dtype=pair_type)
            pairs['context'], pairs['next'] = unique['context'], unique['next']
            del triples, unique
        else:
            pairs = np.empty(count, dtype=pair_type)
            pairs['context'], pairs['next'] = hashes, tokens[order - 1:]
        pairs, counts = np.unique(pairs, return_counts=True)
        prefix, successors = pairs['context'], pairs['next']
        contexts, first = np.unique(prefix, return_index=True)
        totals = np.add.reduceat(counts, first)
        discount = discounts(counts)
        threshold = 1 if order <= 3 else 2
        keep = counts >= threshold
        prefix, successors, counts = prefix[keep], successors[keep], counts[keep]
        rank_order = np.lexsort((-counts, prefix))
        prefix, successors, counts = prefix[rank_order], successors[rank_order], counts[rank_order]
        keys, first = np.unique(prefix, return_index=True)
        group = np.searchsorted(keys, prefix)
        rank = np.arange(len(prefix)) - first[group]
        cap = 2048 if order == 2 else 64 if order == 3 else 32 if order == 4 else 16
        keep = rank < cap
        prefix, successors, counts = prefix[keep], successors[keep], counts[keep]
        keys, first, lengths = np.unique(prefix, return_index=True, return_counts=True)
        probabilities = ((counts - discount[np.minimum(counts, 3) - 1]) / totals[np.searchsorted(contexts, prefix)]).astype(np.float32)
        state[f'keys_{order}'] = torch.from_numpy(keys.copy())
        state[f'offsets_{order}'] = torch.from_numpy(np.concatenate([np.zeros(1, dtype=np.int64), lengths.cumsum()]).astype(np.int32))
        state[f'ids_{order}'] = torch.from_numpy(successors.copy())
        state[f'probs_{order}'] = torch.from_numpy(probabilities.copy())
        state[f'mass_{order}'] = torch.from_numpy(np.add.reduceat(probabilities, first))
        shapes.append([len(keys), len(successors)])
        details.append(dict(order=order, contexts=len(keys), entries=len(successors), discount=discount.tolist(),
                            observed_hash_collisions=collisions, min_count=threshold, cap=cap))
        print(json.dumps(details[-1]), flush=True)
    metadata = dict(seconds=time.perf_counter() - started, smoothing='modified_kn_pruned',
                    training_tokens=len(tokens), fit_targets_new=len(tokens) - 1,
                    training_sha256=sha(source), hash_base=base, max_order=args.max_order, orders=details)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    torch.save(dict(config=dict(memory_shapes=shapes, memory_hash_base=base), state=state, metadata=metadata), args.output)
    metadata['bytes'] = args.output.stat().st_size
    args.output.with_suffix('.json').write_text(json.dumps(metadata, indent=2) + '\n')
    print(json.dumps(metadata, indent=2))


if __name__ == '__main__':
    main()
